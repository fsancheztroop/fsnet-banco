<?php
session_start();

// Verificar si el usuario es admin
if (!isset($_SESSION['username']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit;
}

// Obtener el nombre de usuario de la URL
$username = isset($_GET['username']) ? strtolower($_GET['username']) : '';

if (!$username) {
    echo "Error: No se especificó el nombre de usuario.";
    exit;
}

// Cargar usuarios desde el archivo JSON
$usuarios = json_decode(file_get_contents('users/usuarios.json'), true)['users'];

// Buscar al usuario
$usuario_encontrado = null;
foreach ($usuarios as $user) {
    if (strtolower($user['username']) === $username) {
        $usuario_encontrado = $user;
        break;
    }
}

if (!$usuario_encontrado) {
    echo "Error: No se encontró al usuario.";
    exit;
}

// Cargar el archivo JSON de movimientos del usuario
$cuenta_json_path = 'cuentas/' . strtolower($username) . '.json';
if (!file_exists($cuenta_json_path)) {
    echo "Error: No se encontró el archivo de movimientos para el usuario.";
    exit;
}

$movimientos = json_decode(file_get_contents($cuenta_json_path), true);

// Verificar si la lectura de los movimientos fue exitosa
if ($movimientos === null) {
    echo "Error: No se pudo leer el archivo JSON de movimientos.";
    exit;
}

// Cargar el archivo de configuración para obtener el % de interés mensual
$config_path = 'config.json';
$interes_mensual = 0;
if (file_exists($config_path)) {
    $config = json_decode(file_get_contents($config_path), true);
    $interes_mensual = isset($config['interes_mensual']) ? $config['interes_mensual'] * 100 : 0; // Convertir a porcentaje
}

// Calcular valores de la cuenta
$capital = 0;
$total_en_cuenta = 0;
$rendimientos_totales = 0;

foreach ($movimientos as $movimiento) {
    if ($movimiento['tipo'] === 'Ingreso') {
        $capital += $movimiento['monto'];
    } elseif ($movimiento['tipo'] === 'Rendimiento') {
        $rendimientos_totales += $movimiento['monto'];
    }
    $total_en_cuenta = $movimiento['total_en_cuenta'];
}

// Agrupar movimientos consecutivos de "Rendimiento"
$agrupados = [];
$consecutivos = [];
foreach ($movimientos as $movimiento) {
    if ($movimiento['tipo'] === 'Rendimiento') {
        $consecutivos[] = $movimiento; // Acumular los consecutivos
    } else {
        // Si se encuentra un movimiento diferente, agregar los acumulados como un grupo
        if (count($consecutivos) > 1) {
            $suma_rendimientos = array_sum(array_column($consecutivos, 'monto'));
            $primer_movimiento = $consecutivos[0];
            $ultimo_movimiento = end($consecutivos);
            $dias = count($consecutivos); // Número de días de rendimientos consecutivos
            $agrupados[] = [
                'fecha' => $primer_movimiento['fecha'],
                'tipo' => 'Rendimientos',
                'monto' => $suma_rendimientos,
                'concepto' => 'Rendimientos x ' . $dias . ' días',
                'total_en_cuenta' => $ultimo_movimiento['total_en_cuenta']
            ];
        } elseif (count($consecutivos) === 1) {
            $agrupados[] = array_shift($consecutivos); // Agregar el único movimiento
        }
        $consecutivos = [];
        $agrupados[] = $movimiento; // Agregar el movimiento no rendimiento
    }
}

// Si al final quedan rendimientos consecutivos sin procesar
if (count($consecutivos) > 1) {
    $suma_rendimientos = array_sum(array_column($consecutivos, 'monto'));
    $primer_movimiento = $consecutivos[0];
    $ultimo_movimiento = end($consecutivos);
    $dias = count($consecutivos); // Número de días de rendimientos consecutivos
    $agrupados[] = [
        'fecha' => $primer_movimiento['fecha'],
        'tipo' => 'Rendimientos',
        'monto' => $suma_rendimientos,
        'concepto' => 'Rendimientos x ' . $dias . ' días',
        'total_en_cuenta' => $ultimo_movimiento['total_en_cuenta']
    ];
} elseif (count($consecutivos) === 1) {
    $agrupados[] = array_shift($consecutivos);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalles del Usuario - BANCO FSNET</title>
    <link rel="stylesheet" href="assets/css/style.css?=v24">
</head>
<body>
    <div class="container">
        <div class="panel">
            <h1>Detalles de la Cuenta de: <?= htmlspecialchars($usuario_encontrado['name']) ?></h1>
            <p><strong>Usuario:</strong> <?= htmlspecialchars($usuario_encontrado['username']) ?></p>
            <p><strong>% de interés mensual aplicado:</strong> <?= number_format($interes_mensual, 2) ?>%</p>
            <p><strong>Total en cuenta:</strong> $<?= number_format($total_en_cuenta, 2) ?></p>
            <p><strong>Capital:</strong> $<?= number_format($capital, 2) ?></p>
            <p><strong>Rendimientos totales:</strong> $<?= number_format($rendimientos_totales, 2) ?></p>

            <h2>Movimientos de la Cuenta</h2>
            <table>
                <thead>
                    <tr>
                        <th>Fecha</th>
                        <th>Tipo de movimiento</th>
                        <th>Concepto</th>
                        <th>Monto</th>
                        <th>Total en cuenta</th>
                    </tr>
                </thead>
				<tbody>
					<?php foreach (array_slice($agrupados, -10) as $movimiento): ?>
						<tr>
							<td><?= htmlspecialchars($movimiento['fecha']); ?></td>
							<td><?= htmlspecialchars($movimiento['tipo']); ?></td>
							<td>
								<?php if ($movimiento['tipo'] === 'Egreso'): ?>
									-$<?= number_format($movimiento['monto'], 2); ?>
								<?php else: ?>
									$<?= number_format($movimiento['monto'], 2); ?>
								<?php endif; ?>
							</td>
							<td><?= htmlspecialchars($movimiento['concepto']); ?></td>
							<td>$<?= number_format($movimiento['total_en_cuenta'], 2); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
            </table>

            <!-- Botón para volver al panel de admin -->
            <a href="admin.php" class="btn">Volver al Panel de Administrador</a>
        </div>
    </div>
</body>
</html>
