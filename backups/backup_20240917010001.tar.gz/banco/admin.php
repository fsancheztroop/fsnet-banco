<?php
session_start();

// Verificar si el usuario es admin
if (!isset($_SESSION['usuario']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit;
}

// Cargar todos los usuarios desde JSON
$usuarios = json_decode(file_get_contents('users/usuarios.json'), true)['users'];

// Leer el archivo de configuración para obtener el interés mensual
$config_path = 'config.json';
$config = json_decode(file_get_contents($config_path), true);
$interes_mensual = $config['interes_mensual'] ?? 0.02; // Valor predeterminado del 2%

$mensaje_exito = '';

// Si se envía el formulario de nuevo movimiento, crear un nuevo movimiento
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['usuario'])) {
    $usuario_target = $_POST['usuario'];
    $tipo_movimiento = $_POST['tipo'];
    $monto = floatval($_POST['monto']);
    $concepto = $_POST['concepto'];

    // Cargar los movimientos del usuario seleccionado
    $cuenta_json_path = 'cuentas/' . strtolower($usuario_target) . '.json';
    $movimientos = [];

    if (file_exists($cuenta_json_path)) {
        $movimientos = json_decode(file_get_contents($cuenta_json_path), true);
    }

    // Calcular el total actual en cuenta
    $total_actual = end($movimientos)['total_en_cuenta'] ?? 0;

    // Crear un nuevo movimiento
    $nuevo_movimiento = [
        'fecha' => date('Y-m-d H:i:s'),
        'tipo' => $tipo_movimiento,
        'monto' => $monto,
        'concepto' => htmlspecialchars($concepto),
        'total_en_cuenta' => ($tipo_movimiento === 'Ingreso') ? $total_actual + $monto : $total_actual - $monto
    ];

    // Agregar el nuevo movimiento
    $movimientos[] = $nuevo_movimiento;

    // Guardar los movimientos actualizados en el archivo JSON del usuario
    file_put_contents($cuenta_json_path, json_encode($movimientos, JSON_PRETTY_PRINT));

    $mensaje_exito = "Movimiento creado correctamente para $usuario_target.";
}

// Función para calcular los rendimientos
function calcularRendimientos($movimientos, $dias) {
    $rendimientos = 0;
    $fecha_limite = new DateTime();
    $fecha_limite->modify("-$dias days");
    foreach ($movimientos as $movimiento) {
        $fecha_movimiento = new DateTime($movimiento['fecha']);
        if ($movimiento['tipo'] === 'Rendimiento' && $fecha_movimiento >= $fecha_limite) {
            $rendimientos += $movimiento['monto'];
        }
    }
    return $rendimientos;
}

// Mostrar la información general de cada usuario
$informacion_usuarios = [];
foreach ($usuarios as $user) {
    $cuenta_json_path = 'cuentas/' . strtolower($user['username']) . '.json';
    $movimientos = [];
    if (file_exists($cuenta_json_path)) {
        $movimientos = json_decode(file_get_contents($cuenta_json_path), true);
    }

    $capital = 0;
    $rendimientos_totales = 0;
    $total_en_cuenta = 0;
    $rendimientos_ult_dia = calcularRendimientos($movimientos, 1);
    $rendimientos_ult_30_dias = calcularRendimientos($movimientos, 30);

    foreach ($movimientos as $movimiento) {
        if ($movimiento['tipo'] === 'Ingreso') {
            $capital += $movimiento['monto'];
        }
        if ($movimiento['tipo'] === 'Rendimiento') {
            $rendimientos_totales += $movimiento['monto'];
        }
        $total_en_cuenta = $movimiento['total_en_cuenta'];
    }

    $informacion_usuarios[] = [
        'nombre' => $user['name'],
        'username' => $user['username'],
        'total_en_cuenta' => $total_en_cuenta,
        'capital' => $capital,
        'rendimientos_totales' => $rendimientos_totales,
        'rendimientos_ult_dia' => $rendimientos_ult_dia,
        'rendimientos_ult_30_dias' => $rendimientos_ult_30_dias
    ];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - BANCO FSNET</title>
    <link rel="stylesheet" href="assets/css/style.css?=v24">
</head>
<body>
    <!-- Botón de Cerrar Sesión -->
    <form action="logout.php" method="POST" class="logout-btn">
        <button type="submit">Cerrar Sesión</button>
    </form>

    <div class="container">
        <div class="panel">
            <h1>Panel de Administrador</h1>
            <?php if ($mensaje_exito): ?>
                <p class="success"><?= htmlspecialchars($mensaje_exito) ?></p>
            <?php endif; ?>

            <h2>Configurar % de interés mensual</h2>
            <form method="POST" action="admin.php">
                <label for="interes">Interés mensual (%):</label>
                <input type="number" step="0.01" id="interes" name="interes" value="<?= $interes_mensual * 100 ?>" required>
                <button type="submit">Actualizar Interés</button>
            </form>

            <h2>Información de todos los usuarios</h2>
            <table>
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Total en Cuenta</th>
                        <th>Capital</th>
                        <th>Rendimientos Totales</th>
                        <th>Rendimientos Último Día</th>
                        <th>Rendimientos Últimos 30 Días</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($informacion_usuarios as $info): ?>
                        <tr>
                            <td><?= htmlspecialchars($info['nombre']) ?></td>
                            <td>$<?= number_format($info['total_en_cuenta'], 2) ?></td>
                            <td>$<?= number_format($info['capital'], 2) ?></td>
                            <td>$<?= number_format($info['rendimientos_totales'], 2) ?></td>
                            <td>$<?= number_format($info['rendimientos_ult_dia'], 2) ?></td>
                            <td>$<?= number_format($info['rendimientos_ult_30_dias'], 2) ?></td>
                            <td>
                                <a href="ver_usuario.php?username=<?= urlencode($info['username']) ?>">Ver detalles</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <h2>Crear nuevo movimiento</h2>
            <form method="POST" action="admin.php">
                <label for="usuario">Seleccionar usuario:</label>
                <select name="usuario" id="usuario" required>
                    <?php foreach ($usuarios as $user): ?>
                        <option value="<?= htmlspecialchars($user['username']); ?>"><?= htmlspecialchars($user['name']); ?></option>
                    <?php endforeach; ?>
                </select>

                <label for="tipo">Tipo de movimiento:</label>
                <select name="tipo" id="tipo" required>
                    <option value="Ingreso">Ingreso</option>
                    <option value="Egreso">Egreso</option>
                </select>

                <label for="monto">Monto:</label>
                <input type="number" step="0.01" id="monto" name="monto" required>

                <label for="concepto">Concepto:</label>
                <input type="text" id="concepto" name="concepto" required>

                <button type="submit">Crear Movimiento</button>
            </form>
        </div>
    </div>
</body>
</html>
