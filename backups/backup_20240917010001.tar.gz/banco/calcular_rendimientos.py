import json
from datetime import datetime

# Ruta de los archivos
usuarios_path = '/var/www/html/banco/users/usuarios.json'
cuentas_base_path = '/var/www/html/banco/cuentas/'
config_path = '/var/www/html/banco/config.json'

# Cargar usuarios desde JSON
with open(usuarios_path, 'r') as f:
    usuarios = json.load(f)['users']

# Cargar el archivo de configuración para obtener el % de interés mensual
with open(config_path, 'r') as f:
    config = json.load(f)
    interes_mensual = config.get('interes_mensual', 0.02)  # Valor predeterminado del 2%

# Función para agregar el rendimiento diario a cada cuenta
def agregar_rendimiento_diario():
    for usuario in usuarios:
        username = usuario['username'].lower()
        cuenta_json_path = f'{cuentas_base_path}{username}.json'

        # Verificar si existe el archivo de cuenta del usuario
        try:
            with open(cuenta_json_path, 'r') as f:
                movimientos = json.load(f)
        except FileNotFoundError:
            print(f"Error: No se encontró la cuenta del usuario {username}")
            continue
        
        # Obtener el total en cuenta del último movimiento
        if movimientos:
            ultimo_movimiento = movimientos[-1]
            total_en_cuenta = ultimo_movimiento.get('total_en_cuenta', 0)
        
            # Solo calcular rendimientos si el total en cuenta es mayor a 0
            if total_en_cuenta > 0:
                # Calcular rendimiento diario
                rendimiento_diario = (total_en_cuenta * interes_mensual) / 30
                
                # Crear nuevo movimiento de rendimiento
                nuevo_movimiento = {
                    'fecha': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'tipo': 'Rendimiento',
                    'monto': round(rendimiento_diario, 2),
                    'concepto': 'Rendimiento obtenido',
                    'total_en_cuenta': round(total_en_cuenta + rendimiento_diario, 2)
                }

                # Agregar el nuevo movimiento
                movimientos.append(nuevo_movimiento)

                # Guardar los movimientos actualizados en el archivo JSON
                with open(cuenta_json_path, 'w') as f:
                    json.dump(movimientos, f, indent=4)

                print(f"Rendimiento de {rendimiento_diario:.2f} agregado para {username}")
            else:
                print(f"El total en cuenta de {username} es <= 0, no se agrega rendimiento")
        else:
            print(f"No hay movimientos previos para el usuario {username}")

# Ejecutar la función
agregar_rendimiento_diario()
