<?php
session_start();

// Verificar si el usuario es cliente
if (!isset($_SESSION['usuario']) || $_SESSION['role'] !== 'cliente') {
    header('Location: index.php');
    exit;
}

// Nombre de usuario desde la sesión
$nombre_usuario = $_SESSION['usuario']; // Nombre del usuario
$username = $_SESSION['username']; // Username del usuario

// Cargar los movimientos del cliente desde su archivo JSON, basado en el nombre de usuario
$cuenta_json_path = 'cuentas/' . strtolower($username) . '.json';
$movimientos = [];

if (file_exists($cuenta_json_path)) {
    $movimientos = json_decode(file_get_contents($cuenta_json_path), true);
}

// Calcular capital, rendimientos, rendimientos del último día y últimos 30 días
$capital = 0;
$rendimientos = 0;
$rendimientos_ult_dia = 0;
$rendimientos_ult_30_dias = 0;
$total_en_cuenta = 0;
$fecha_actual = new DateTime();
$fecha_ayer = clone $fecha_actual;
$fecha_ayer->modify('-1 day');
$fecha_30_dias = clone $fecha_actual;
$fecha_30_dias->modify('-30 days');

// Arrays para los datos del gráfico, agrupados por mes
$totales_por_mes = [];
$fechas_por_mes = [];

// Procesar los movimientos para calcular los valores necesarios
foreach ($movimientos as $movimiento) {
    $fecha_movimiento = new DateTime($movimiento['fecha']);
    $mes = $fecha_movimiento->format('Y-m'); // Agrupar por año-mes

    // Calcular capital y rendimientos
    if ($movimiento['tipo'] === 'Ingreso') {
        $capital += $movimiento['monto'];
    } elseif ($movimiento['tipo'] === 'Rendimiento') {
        $rendimientos += $movimiento['monto'];
    }

    // Guardar el último total en cuenta para cada mes
    $totales_por_mes[$mes] = $movimiento['total_en_cuenta'];

    // Calcular rendimientos del último día
    if ($movimiento['tipo'] === 'Rendimiento' && $fecha_movimiento >= $fecha_ayer) {
        $rendimientos_ult_dia += $movimiento['monto'];
    }

    // Calcular rendimientos de los últimos 30 días
    if ($movimiento['tipo'] === 'Rendimiento' && $fecha_movimiento >= $fecha_30_dias) {
        $rendimientos_ult_30_dias += $movimiento['monto'];
    }

    // Total en cuenta
    $total_en_cuenta = $movimiento['total_en_cuenta'];
}

// Extraer las fechas y los totales por mes
$fechas_por_mes = array_keys($totales_por_mes);
$totales = array_values($totales_por_mes);

// Agrupar movimientos consecutivos de "Rendimiento"
$agrupados = [];
$consecutivos = [];
foreach ($movimientos as $movimiento) {
    if ($movimiento['tipo'] === 'Rendimiento') {
        $consecutivos[] = $movimiento; // Acumular los consecutivos
    } else {
        // Si se encuentra un movimiento diferente, agregar los acumulados como un grupo
        if (count($consecutivos) > 1) {
            $suma_rendimientos = array_sum(array_column($consecutivos, 'monto'));
            $primer_movimiento = $consecutivos[0];
            $ultimo_movimiento = end($consecutivos);
            $dias = count($consecutivos); // Número de días de rendimientos consecutivos
            $agrupados[] = [
                'fecha' => $primer_movimiento['fecha'],
                'tipo' => 'Rendimientos',
                'monto' => $suma_rendimientos,
                'concepto' => 'Rendimientos x ' . $dias . ' días',
                'total_en_cuenta' => $ultimo_movimiento['total_en_cuenta']
            ];
        } elseif (count($consecutivos) === 1) {
            $agrupados[] = array_shift($consecutivos); // Agregar el único movimiento
        }
        $consecutivos = [];
        $agrupados[] = $movimiento; // Agregar el movimiento no rendimiento
    }
}

// Si al final quedan rendimientos consecutivos sin procesar
if (count($consecutivos) > 1) {
    $suma_rendimientos = array_sum(array_column($consecutivos, 'monto'));
    $primer_movimiento = $consecutivos[0];
    $ultimo_movimiento = end($consecutivos);
    $dias = count($consecutivos); // Número de días de rendimientos consecutivos
    $agrupados[] = [
        'fecha' => $primer_movimiento['fecha'],
        'tipo' => 'Rendimientos',
        'monto' => $suma_rendimientos,
        'concepto' => 'Rendimientos x ' . $dias . ' días',
        'total_en_cuenta' => $ultimo_movimiento['total_en_cuenta']
    ];
} elseif (count($consecutivos) === 1) {
    $agrupados[] = array_shift($consecutivos);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Caja de Ahorro - BANCO FSNET</title>
    <link rel="stylesheet" href="assets/css/style.css?=v24">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <!-- Botón de Cerrar Sesión en la esquina superior derecha -->
    <form action="logout.php" method="POST" class="logout-btn">
        <button type="submit">Cerrar Sesión</button>
    </form>

    <div class="container">
        <img src="logo.png" alt="Logo Banco FSNET" class="logo">
        <div class="panel">
            <h1>Bienvenido, <?= htmlspecialchars($nombre_usuario); ?></h1>

            <div class="account-info">
                <h2>Caja de Ahorro de: <?= htmlspecialchars($nombre_usuario); ?></h2>
                <p><strong>Total en cuenta:</strong> $<?= number_format($total_en_cuenta, 2); ?></p>
                <p><strong>Capital:</strong> $<?= number_format($capital, 2); ?></p>
                <p><strong>Rendimientos:</strong> $<?= number_format($rendimientos, 2); ?></p>
                <p><strong>Rendimientos del último día:</strong> $<?= number_format($rendimientos_ult_dia, 2); ?></p>
                <p><strong>Rendimientos de los últimos 30 días:</strong> $<?= number_format($rendimientos_ult_30_dias, 2); ?></p>
            </div>

            <!-- Gráfico de evolución mensual -->
            <div class="chart-container">
			<canvas id="accountChart"></canvas>
			</div>

			<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
			<script>
				// Extraer las fechas y los totales de los movimientos para el gráfico
				const fechas = <?= json_encode(array_unique(array_map(function ($mov) {
					return (new DateTime($mov['fecha']))->format('Y-m'); // Agrupar por mes y año
				}, $movimientos))); ?>;

				const totales = <?= json_encode(array_values(array_reduce($movimientos, function ($carry, $mov) {
					$mes = (new DateTime($mov['fecha']))->format('Y-m');
					$carry[$mes] = $mov['total_en_cuenta'];
					return $carry;
				}, []))); ?>;

				const ctx = document.getElementById('accountChart').getContext('2d');
				const accountChart = new Chart(ctx, {
					type: 'line',
					data: {
						labels: fechas, // Fechas de los movimientos por mes
						datasets: [{
							label: 'Evolución del Total en Cuenta',
							data: totales, // Total en cuenta para cada mes
							borderColor: 'rgba(75, 192, 192, 1)',
							fill: false,
							tension: 0.1
						}]
					},
					options: {
						scales: {
							x: {
								title: {
									display: true,
									text: 'Mes'
								}
							},
							y: {
								title: {
									display: true,
									text: 'Total en Cuenta ($)'
								},
								beginAtZero: true
							}
						}
					}
				});
			</script>
			
            <div class="movements">
                <h3>Últimos 10 movimientos</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Tipo de Movimiento</th>
                            <th>Monto</th>
                            <th>Concepto</th>
                            <th>Total en Cuenta</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach (array_slice($agrupados, -10) as $movimiento): ?>
                            <tr>
                                <td><?= htmlspecialchars($movimiento['fecha']); ?></td>
                                <td><?= htmlspecialchars($movimiento['tipo']); ?></td>
                                <td>$<?= number_format($movimiento['monto'], 2); ?></td>
                                <td><?= htmlspecialchars($movimiento['concepto']); ?></td>
                                <td>$<?= number_format($movimiento['total_en_cuenta'], 2); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</body>
</html>
